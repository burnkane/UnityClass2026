using UnityEngine;

public class AddScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("�ֵ彺ũ��Ʈ");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
