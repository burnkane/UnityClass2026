USAGE

To use the Free Aircraft Pack, you can simply drag the model (in folder "Models") or the prefab (in folder "Prefabs") into the scene.


LICENSE

Thank you for downloading the Free Aircraft Pack! 

You are free to use it for your personal and commercial projects.

You are not allowed to redistribute any or all models of this package in any shape or form unless it is embedded in your own project.

Simply put, you cannot resell or redistribute anything in this package by itself. You can only put it in your games for use as intended.

No attribution is required, but a link in the credits is greatly appreciated. 



We will be happy to receive a positive review.
Thank you and regards your Understone Team!